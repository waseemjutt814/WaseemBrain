from __future__ import annotations

import subprocess
from typing import TypedDict, Optional, List
from loguru import logger

class FirewallRule(TypedDict):
    name: str
    direction: str # in | out
    action: str # allow | block
    protocol: str # TCP | UDP | ICMPv4
    local_port: Optional[str]

class SystemOperations:
    """Industrial-grade System Operations for WaseemBrain."""
    
    @staticmethod
    def get_firewall_rules(name_filter: Optional[str] = None) -> List[str]:
        """Retrieve current Windows Firewall rules."""
        cmd = ["netsh", "advfirewall", "firewall", "show", "rule", "name=all"]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            lines = result.stdout.splitlines()
            if name_filter:
                return [line for line in lines if name_filter.lower() in line.lower()]
            return lines
        except Exception as e:
            logger.error(f"Failed to fetch firewall rules: {e}")
            return [f"Error: {e}"]

    @staticmethod
    def add_firewall_rule(rule: FirewallRule) -> str:
        """Add a new Windows Firewall rule."""
        cmd = [
            "netsh", "advfirewall", "firewall", "add", "rule",
            f"name={rule['name']}",
            f"dir={rule['direction']}",
            f"action={rule['action']}",
            f"protocol={rule['protocol']}"
        ]
        if rule.get("local_port"):
            cmd.append(f"localport={rule['local_port']}")
            
        try:
            subprocess.run(cmd, check=True, capture_output=True)
            return f"Successfully added firewall rule: {rule['name']}"
        except subprocess.CalledProcessError as e:
            return f"Failed to add firewall rule: {e.stderr}"

    @staticmethod
    def run_in_sandbox(command: str, timeout: int = 10) -> str:
        """Execute a command in a theoretical sandboxed environment (restricted shell)."""
        # In a real industrial setting, this would use containers or restricted tokens.
        # For this local Windows env, we use a restricted subprocess with no shell and limited env.
        try:
            # Empty environment to restrict access
            result = subprocess.run(
                command, 
                shell=False, 
                capture_output=True, 
                text=True, 
                timeout=timeout,
                env={} 
            )
            return result.stdout if result.stdout else result.stderr
        except subprocess.TimeoutExpired:
            return "Sandbox Execution Timeout: Process terminated for safety."
        except Exception as e:
            return f"Sandbox Error: {e}"
