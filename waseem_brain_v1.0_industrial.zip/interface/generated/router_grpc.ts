export interface RouterDecision {
  expert_ids: string[];
  check_memory_first: boolean;
  internet_needed: boolean;
  confidence: number;
  reasoning_trace: string;
  latency_ms: number;
}
