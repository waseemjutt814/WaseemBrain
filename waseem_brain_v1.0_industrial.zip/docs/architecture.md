# Architecture Overview

## System Design

WaseemBrain is a sparse-activation local AI architecture designed for efficient, privacy-preserving intelligence.

## Core Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Interface Layer                         │
│                    (Fastify + WebSocket)                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     Coordinator Layer                        │
│                  (brain/coordinator.py)                      │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐          │
│  │ Normalizer  │→ │   Router    │→ │   Experts   │          │
│  └─────────────┘  └─────────────┘  └─────────────┘          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      Core Systems                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │  Memory  │  │  Router  │  │ Internet │  │ Learning │     │
│  │  Graph   │  │  Daemon  │  │  Module  │  │ Pipeline │     │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │
└─────────────────────────────────────────────────────────────┘
```

## Data Flow

1. **Input Normalization**: Raw input converted to `NormalizedSignal`
2. **Emotion Encoding**: Text/voice analyzed for emotional context
3. **Router Decision**: Determine which experts are needed
4. **Memory Recall**: Fetch relevant context from memory graph
5. **Expert Inference**: Selected experts process the query
6. **Response Assembly**: Combine expert outputs into final response

## Thread Safety

The `ExpertPool` uses `asyncio.Lock` for thread-safe operations:

- `load_async()`: Thread-safe expert loading
- `evict_idle_async()`: Thread-safe eviction
- Background evictor with proper cancellation

## Type System

Branded types for compile-time safety:

```python
SessionId = _BrandedStr  # Nominal session identifier
ExpertId = _BrandedStr   # Nominal expert identifier  
MemoryNodeId = _BrandedStr  # Nominal memory node identifier
EmbeddingVector = tuple[float, ...]  # Vector embedding
```

Result type for error handling:

```python
Result[T, E] = OkResult[T] | ErrResult[E]
```

## Configuration

All settings in `BrainSettings` dataclass:

- Frozen (immutable) for safety
- Environment variable overrides
- Sensible defaults

## Performance Characteristics

| Component | Latency | Memory |
|-----------|---------|--------|
| Router | < 1ms | Minimal |
| Memory Recall | 10-50ms | Depends on index size |
| Expert Inference | 100-500ms | Per loaded expert |
| Full Pipeline | 200-600ms | ~500MB base |

## Scalability

- **Horizontal**: Multiple coordinator instances
- **Vertical**: Increase `expert_max_loaded`
- **Memory**: HNSW index scales O(n log n)
