# API Reference

## Core Types

### Result Types

```python
from brain.types import ok, err, Result, is_ok, is_err

# Create success result
result: Result[str, str] = ok("success value")

# Create error result
result: Result[str, str] = err("error message")

# Check result type
if is_ok(result):
    value = result["value"]
elif is_err(result):
    error = result["error"]
```

### Branded Types

```python
from brain.types import SessionId, ExpertId, MemoryNodeId, EmbeddingVector

# Create branded identifiers
session_id = SessionId("session-123")
expert_id = ExpertId("code-expert")
memory_id = MemoryNodeId("mem-abc123")

# Create embedding vector
embedding = EmbeddingVector([0.1, 0.2, 0.3, 0.4])
```

### TypedDict Types

```python
from brain.types import (
    NormalizedSignal,
    EmotionContext,
    RouterDecision,
    DialogueState,
    ResponsePlan,
    MemoryNode,
    ExpertOutput,
)

# Normalized signal
signal: NormalizedSignal = {
    "text": "Hello world",
    "modality": "text",
    "session_id": SessionId("test"),
}

# Emotion context
emotion: EmotionContext = {
    "primary_emotion": "happy",
    "valence": 0.7,
    "arousal": 0.5,
    "confidence": 0.9,
    "source": "text",
}

# Router decision
decision: RouterDecision = {
    "experts_needed": [ExpertId("code-expert")],
    "check_memory_first": True,
    "internet_needed": False,
    "confidence": 0.85,
    "reasoning_trace": "Code query detected",
}
```

## Brain Runtime

### Initialization

```python
from brain.runtime import WaseemBrainRuntime
from brain.config import load_settings

# Initialize with default settings
runtime = WaseemBrainRuntime()

# Initialize with custom settings
settings = load_settings({"INTERNET_ENABLED": "false"})
runtime = WaseemBrainRuntime(settings=settings)
```

### Query Processing

```python
# Process a query
result = await runtime.query(
    text="What is the error in my code?",
    session_id=SessionId("user-123"),
)

if result["ok"]:
    response = result["value"]
    print(response["content"])
```

### Health Check

```python
# Get system health
health = runtime.health()
print(health["status"])  # "healthy" | "degraded" | "unhealthy"
```

### Cleanup

```python
# Graceful shutdown
runtime.close()
```

## Expert Pool

### Thread-Safe Operations

```python
from brain.experts.pool import ExpertPool

pool = ExpertPool()

# Async load (thread-safe)
result = await pool.load_async(ExpertId("code-expert"))

# Async inference
outputs = await pool.infer(
    expert_ids=[ExpertId("code-expert")],
    request="Analyze this code",
)

# Async idle eviction
evicted = await pool.evict_idle_async()
```

### Sync Operations (Backward Compatible)

```python
# Sync load
result = pool.load(ExpertId("code-expert"))

# Sync eviction
evicted = pool.evict_idle()
```

## Memory Graph

### Store Memory

```python
from brain.memory.graph import MemoryGraph

memory = MemoryGraph()

# Store a memory
result = memory.store(
    content="User asked about Python errors",
    source="session",
    tags=["python", "error"],
    session_id=SessionId("session-123"),
    source_type="session",
)
```

### Recall Memory

```python
# Recall relevant memories
result = memory.recall(
    query="Python error handling",
    limit=5,
    session_id=SessionId("session-123"),
)

if result["ok"]:
    for node in result["value"]:
        print(node["content"])
```

## Router Client

### Artifact Router

```python
from brain.router.client import ArtifactRouterClient

client = ArtifactRouterClient()

decision = client.decide(signal, emotion_context)
if decision["ok"]:
    experts = decision["value"]["experts_needed"]
```

### Daemon Router

```python
from brain.router.client import RouterDaemonClient

client = RouterDaemonClient("localhost:50051")

decision = client.decide(signal, emotion_context)
```

### Hybrid Router

```python
from brain.router.client import HybridRouterClient, RouterDaemonClient, ArtifactRouterClient

primary = RouterDaemonClient("localhost:50051")
fallback = ArtifactRouterClient()

client = HybridRouterClient(primary, fallback)
decision = client.decide(signal, emotion_context)
```

## Dialogue Planner

### Build State

```python
from brain.dialogue import DialoguePlanner

planner = DialoguePlanner()

state = planner.build_state(signal, emotion, memory_nodes)
print(state["intent"])  # "code" | "factual" | "planning" | ...
```

### Build Response Plan

```python
plan = planner.build_plan(
    signal,
    state,
    router_confidence=0.8,
    has_evidence=True,
    has_memory_answer=False,
)
print(plan["mode"])  # "answer" | "clarify" | "plan" | ...
```

## Configuration

### Environment Variables

```bash
# Project paths
export PROJECT_ROOT=/path/to/project
export EXPERT_DIR=./experts/base

# Embedding
export EMBEDDING_BACKEND=onnx
export EMBEDDING_MODEL_NAME=all-MiniLM-L6-v2
export EMBEDDING_DIMENSIONS=384

# Internet
export INTERNET_ENABLED=true
export INTERNET_MAX_REQUESTS_PER_QUERY=5

# Experts
export EXPERT_MAX_LOADED=3
export EXPERT_IDLE_TIMEOUT_SEC=30

# Router
export ROUTER_BACKEND=auto
export ROUTER_CONFIDENCE_THRESHOLD=0.7
```

### Programmatic Configuration

```python
from brain.config import BrainSettings, load_settings

# Load from environment
settings = load_settings()

# Create custom settings
settings = BrainSettings(
    repo_root=Path("/custom/path"),
    internet_enabled=False,
    expert_max_loaded=5,
    # ... all other fields required
)
```
