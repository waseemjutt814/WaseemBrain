# Components Deep Dive

## Brain Runtime (`brain/runtime.py`)

The central orchestrator that initializes and manages all components.

### Key Methods

| Method | Purpose |
|--------|---------|
| `query()` | Process user query |
| `health()` | System health check |
| `recall()` | Memory recall |
| `experts()` | Expert status |
| `close()` | Graceful shutdown |

### Initialization Flow

```python
1. Load settings
2. Initialize MemoryGraph
3. Initialize ExpertRegistry
4. Initialize ExpertPool
5. Initialize InternetModule
6. Initialize Coordinator
7. Start background tasks
```

---

## Coordinator (`brain/coordinator.py`)

Orchestrates the flow of information through the system.

### Processing Pipeline

```python
async def process(signal: NormalizedSignal) -> AsyncGenerator[str, None]:
    # 1. Normalize signal
    normalized = self._normalizer.normalize(signal)
    
    # 2. Encode emotion
    emotion = self._emotion_encoder.encode(normalized)
    
    # 3. Get router decision
    decision = self._router.decide(normalized, emotion)
    
    # 4. Recall memory if needed
    memory_nodes = []
    if decision["check_memory_first"]:
        memory_nodes = self._memory.recall(normalized["text"])
    
    # 5. Build dialogue state
    state = self._dialogue.build_state(normalized, emotion, memory_nodes)
    
    # 6. Build response plan
    plan = self._dialogue.build_plan(normalized, state, ...)
    
    # 7. Run expert inference
    outputs = self._expert_pool.infer(decision["experts_needed"], request)
    
    # 8. Assemble response
    yield self._assemble_response(outputs, plan)
```

---

## Expert Pool (`brain/experts/pool.py`)

Thread-safe pool managing loaded experts.

### Thread Safety

```python
class ExpertPool:
    def __init__(self):
        self._lock = asyncio.Lock()  # Thread-safe access
        self._shutdown = False        # Graceful shutdown flag
    
    async def load_async(self, expert_id: ExpertId) -> Result[Expert, str]:
        async with self._lock:
            return self._load_unsafe(expert_id)
    
    async def evict_idle_async(self) -> list[ExpertId]:
        async with self._lock:
            return self._evict_idle_unsafe()
```

### Eviction Policy

- LRU (Least Recently Used) eviction
- Configurable idle timeout
- Background eviction task

---

## Memory Graph (`brain/memory/graph.py`)

Vector-based memory storage with semantic recall.

### Storage

```python
def store(content: str, source: str, tags: list[str], 
          session_id: SessionId, source_type: str,
          citations: list[EvidenceReference] | None) -> Result[MemoryNodeId, str]:
    # 1. Validate content
    # 2. Create embedding
    # 3. Find similar memories
    # 4. Create edges to similar nodes
    # 5. Persist to vector store
```

### Recall

```python
def recall(query: str, limit: int, session_id: SessionId | None) -> Result[list[MemoryNode], str]:
    # 1. Vector search
    # 2. Expand to neighbors
    # 3. Score and rank
    # 4. Update access stats
```

### Scoring

```python
def _score_node(query_embedding, node, session_id) -> float:
    similarity = cosine_similarity(query_embedding, node["embedding"])
    recency_weight = 1.0 / (1.0 + days_since_access)
    session_boost = 1.15 if same_session else 1.0
    provenance_boost = 1.1 if has_provenance else 0.8
    
    return similarity * confidence * recency_weight * session_boost * provenance_boost
```

---

## Router (`brain/router/client.py`)

Determines which experts to invoke.

### Client Types

| Client | Use Case |
|--------|----------|
| `ArtifactRouterClient` | Local file-based routing |
| `RouterDaemonClient` | gRPC daemon routing |
| `HybridRouterClient` | Daemon with local fallback |

### Decision Output

```python
RouterDecision = {
    "experts_needed": list[ExpertId],
    "check_memory_first": bool,
    "internet_needed": bool,
    "confidence": float,
    "reasoning_trace": str,
}
```

---

## Dialogue Planner (`brain/dialogue.py`)

Plans response strategy based on query analysis.

### Intent Detection

| Intent | Triggers |
|--------|----------|
| `greeting` | "hi", "hello", "salam" |
| `code` | "bug", "error", "function", "file" |
| `factual` | "what", "where", "who", "when" |
| `planning` | "plan", "steps", "roadmap" |
| `follow_up` | "it", "that", "continue" |

### Response Modes

| Mode | When Used |
|------|-----------|
| `answer` | Clear query with evidence |
| `clarify` | Ambiguous query |
| `plan` | Step-by-step request |
| `memory-recall` | High-confidence memory match |

---

## Internet Module (`brain/internet/module.py`)

Controlled internet access for information retrieval.

### Query Flow

```python
async def query(search_query: str, context: str) -> Result[InternetResult, str]:
    # 1. Refine query with context
    # 2. Search via DuckDuckGo
    # 3. Fetch top results
    # 4. Extract content
    # 5. Create citations
```

### Safety Features

- Domain allowlist
- Request rate limiting
- Cache with TTL
- Timeout protection

---

## Learning Pipeline (`brain/learning/policy.py`)

Offline learning from interaction traces.

### Components

- `ResponsePolicyTrainer`: Learn response preferences
- `ExpertCorrector`: Correct expert outputs
- `TraceCollector`: Collect interaction traces

### Artifacts

- `response-policy.json`: Learned response preferences
- `expert-corrections.json`: Expert output corrections
