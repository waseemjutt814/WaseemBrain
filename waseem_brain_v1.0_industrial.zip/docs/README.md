# WaseemBrain Documentation

> Sparse-activation local AI architecture with memory, experts, and controlled internet access.

## Quick Links

| Document | Description |
|----------|-------------|
| [Architecture](./architecture.md) | System architecture overview |
| [API Reference](./api.md) | API documentation |
| [Components](./components.md) | Component deep dive |
| [Testing Guide](./testing.md) | Testing documentation |
| [Build Guide](./build.md) | Build and deployment |

## Project Structure

```
waseem-brain/
├── brain/                 # Core Python modules
│   ├── config.py          # Configuration management
│   ├── coordinator.py     # Main orchestrator
│   ├── runtime.py         # Runtime environment
│   ├── dialogue.py        # Dialogue planning
│   ├── types.py           # Type definitions
│   ├── experts/           # Expert system
│   │   ├── pool.py        # Expert pool (thread-safe)
│   │   ├── expert.py      # Expert implementations
│   │   └── registry.py    # Expert registry
│   ├── memory/            # Memory system
│   │   ├── graph.py       # Memory graph
│   │   └── embedder.py    # Embedding system
│   ├── router/            # Router system
│   │   └── client.py      # Router clients
│   ├── internet/          # Internet module
│   └── learning/          # Learning pipeline
├── interface/             # TypeScript interface
├── tests/                 # Test suites
│   ├── python/            # Python tests
│   └── typescript/        # TypeScript tests
├── router-daemon/         # Rust router daemon
├── package.json           # Node.js + Python deps
├── pyproject.toml         # Python project config
└── requirements.txt       # Python dependencies
```

## Core Components

### 1. Brain Runtime (`brain/runtime.py`)
- Initializes all components
- Manages health checks
- Coordinates learning processes

### 2. Coordinator (`brain/coordinator.py`)
- Signal normalization
- Router decisions
- Expert inference
- Response assembly

### 3. Expert Pool (`brain/experts/pool.py`)
- Thread-safe expert loading
- Automatic idle eviction
- Async inference support

### 4. Memory Graph (`brain/memory/graph.py`)
- Vector-based memory storage
- Semantic recall
- Provenance tracking

### 5. Router (`brain/router/client.py`)
- Daemon client (gRPC)
- Artifact client (local)
- Hybrid fallback support

## Type System

All types are defined in `brain/types.py`:

```python
# Result types
Result[T, E] = OkResult[T] | ErrResult[E]

# Branded types
SessionId, ExpertId, MemoryNodeId, EmbeddingVector

# TypedDicts
NormalizedSignal, EmotionContext, RouterDecision
DialogueState, ResponsePlan, MemoryNode, ExpertOutput
```

## Configuration

Environment variables (see `brain/config.py`):

| Variable | Default | Description |
|----------|---------|-------------|
| `PROJECT_ROOT` | cwd | Project root directory |
| `EMBEDDING_BACKEND` | auto | Embedding backend |
| `INTERNET_ENABLED` | true | Enable internet access |
| `EXPERT_MAX_LOADED` | 3 | Max loaded experts |
| `ROUTER_BACKEND` | auto | Router backend |

## Testing

```bash
# Run all Python tests
python -m pytest tests/python -v

# Run unified test suite
python -m tests.python.run_all_tests

# Run with coverage
python -m pytest tests/python --cov=brain
```

## Dependencies

All dependencies are consolidated in `package.json`:

- `dependencies`: Node.js runtime deps
- `devDependencies`: Node.js dev deps
- `pythonDependencies.runtime`: Python runtime deps
- `pythonDependencies.dev`: Python dev deps
- `pythonDependencies.training`: ML training deps

## Author

**Muhammad Waseem Akram**

## License

MIT
