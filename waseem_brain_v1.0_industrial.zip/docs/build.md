# Build and Deployment Guide

## Prerequisites

- Python 3.11+
- Node.js 20+
- Rust (optional, for router daemon)

## Installation

### Quick Install

```bash
# Install all dependencies
npm run install:all
```

### Manual Install

```bash
# Node.js dependencies
npm install

# Python dependencies
pip install -r requirements.txt
```

### Development Dependencies

```bash
# Install dev dependencies
pip install -r requirements-dev.txt
```

### Training Dependencies

```bash
# Install ML training dependencies
pip install -r requirements-training.txt
```

## Building

### TypeScript Build

```bash
npm run build
```

### Router Daemon Build

```bash
npm run build:rust
```

### Build All

```bash
npm run build:all
```

## Running

### Development Server

```bash
npm run dev
```

### Production Server

```bash
npm start
```

### Python Runtime

```bash
npm run start:python
```

## Testing

### All Tests

```bash
npm test
```

### Python Tests Only

```bash
npm run test:py
```

### TypeScript Tests Only

```bash
npm run test:ts
```

### Coverage Report

```bash
npm run test:coverage
```

## Linting

```bash
npm run lint
```

## Formatting

```bash
npm run format
```

## Cleaning

```bash
npm run clean
```

## Environment Variables

Create `.env` file:

```bash
# Copy example
cp .env.example .env

# Edit
nano .env
```

Key variables:

| Variable | Description |
|----------|-------------|
| `PROJECT_ROOT` | Project root directory |
| `EMBEDDING_BACKEND` | Embedding backend (auto/onnx) |
| `INTERNET_ENABLED` | Enable internet access |
| `EXPERT_MAX_LOADED` | Max loaded experts |
| `ROUTER_BACKEND` | Router backend (auto/grpc) |

## Docker Deployment

### Build Image

```bash
docker build -t waseem-brain .
```

### Run Container

```bash
docker run -p 8080:8080 waseem-brain
```

## Production Checklist

- [ ] Set `INTERNET_ENABLED=false` for offline mode
- [ ] Configure `INTERNET_ALLOWED_DOMAINS` for restricted access
- [ ] Set `STRICT_RUNTIME=true` for production
- [ ] Configure `LOG_LEVEL=warning` or `error`
- [ ] Set up health monitoring
- [ ] Configure memory limits

## Health Monitoring

### Health Endpoint

```bash
curl http://localhost:8080/health
```

Response:

```json
{
  "status": "healthy",
  "components": {
    "memory": "ok",
    "experts": "ok",
    "router": "ok"
  }
}
```

## Troubleshooting

### Common Issues

1. **Import errors**: Run `pip install -r requirements.txt`
2. **Memory errors**: Reduce `EXPERT_MAX_LOADED`
3. **Router errors**: Check router daemon is running
4. **Slow inference**: Check expert idle timeout

### Logs

Logs are written to:

- Console output
- `logs/` directory (if configured)
