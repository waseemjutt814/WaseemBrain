# Testing Guide

## Test Structure

```text
tests/
├── python/
│   ├── __init__.py              # Environment setup
│   ├── run_all_tests.py         # Unified test runner
│   ├── test_unified.py          # Combined test suite
│   ├── support.py               # Test utilities
│   ├── test_types.py            # Type tests
│   ├── test_config.py           # Config tests
│   ├── test_memory.py           # Memory tests
│   ├── test_experts.py          # Expert tests
│   └── ...                      # More test files
└── typescript/
    └── *.test.ts                # TypeScript tests
```

## Running Tests

### All Tests

```bash
# Run all Python tests
python -m pytest tests/python -v

# Run unified test suite
python -m tests.python.run_all_tests

# Run with coverage
python -m pytest tests/python --cov=brain --cov-report=html
```

### Specific Tests

```bash
# Run specific test file
python -m pytest tests/python/test_types.py -v

# Run specific test class
python -m pytest tests/python/test_unified.py::TestTypes -v

# Run specific test
python -m pytest tests/python/test_unified.py::TestTypes::test_ok_result_creation -v
```

### Test Options

```bash
# Verbose output
python -m pytest tests/python -v

# Stop on first failure
python -m pytest tests/python -x

# Run only fast tests
python -m pytest tests/python -m "not slow"

# Run integration tests
python -m pytest tests/python -m integration
```

## Test Categories

### Unit Tests

- `TestTypes`: Core type definitions
- `TestConfig`: Configuration management
- `TestDialogue`: Dialogue planning logic

### Integration Tests

- `TestIntegration`: Full workflow tests
- `TestMemory`: Memory graph operations
- `TestExperts`: Expert pool operations

### Performance Tests

- `TestPerformance`: Benchmark tests

### Edge Case Tests

- `TestEdgeCases`: Boundary conditions

## Writing Tests

### Basic Test

```python
def test_my_feature() -> None:
    """Test description."""
    result = my_function()
    assert result == expected_value
```

### Parametrized Test

```python
@pytest.mark.parametrize("input,expected", [
    ("hello", "HELLO"),
    ("world", "WORLD"),
])
def test_uppercase(input: str, expected: str) -> None:
    assert input.upper() == expected
```

### Async Test

```python
@pytest.mark.asyncio
async def test_async_operation() -> None:
    result = await async_function()
    assert result["ok"]
```

### Fixture Usage

```python
@pytest.fixture
def mock_settings(tmp_path: Path) -> BrainSettings:
    return load_settings({"PROJECT_ROOT": str(tmp_path)})

def test_with_fixture(mock_settings: BrainSettings) -> None:
    assert mock_settings is not None
```

## Test Report

After running tests, a report is saved to:

```text
tests/python/test_report.txt
```

## Coverage

Generate coverage report:

```bash
python -m pytest tests/python --cov=brain --cov-report=html
```

View report:

```bash
open htmlcov/index.html
```

## Continuous Integration

Tests run automatically on:

- Push to main branch
- Pull requests
- Release tags

## Test Count Summary

| Category | Files | Tests |
|----------|-------|-------|
| Types | 1 | 10+ |
| Config | 1 | 6 |
| Dialogue | 1 | 5+ |
| Memory | 1 | 2+ |
| Experts | 3 | 10+ |
| Router | 1 | 3+ |
| Integration | 1 | 2+ |
| Performance | 1 | 2+ |
| Edge Cases | 1 | 4+ |
| **Total** | **22+** | **50+** |
