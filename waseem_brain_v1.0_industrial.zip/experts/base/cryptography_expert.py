"""Cryptography & Mathematical Algorithms Expert Module.

Provides comprehensive knowledge on encryption, cryptographic algorithms,
mathematical foundations, and secure communication protocols.
"""

from dataclasses import dataclass


@dataclass
class CryptographicAlgorithm:
    """Cryptographic algorithm specification."""
    name: str
    category: str  # Symmetric, Asymmetric, Hashing, Key Derivation
    key_size: str
    use_case: str
    security_strength: str
    pros: list[str]
    cons: list[str]


class CryptographyKnowledgeBase:
    """Comprehensive cryptography knowledge base."""
    
    SYMMETRIC_ALGORITHMS = [
        CryptographicAlgorithm(
            name="AES (Advanced Encryption Standard)",
            category="Symmetric",
            key_size="128, 192, 256 bits",
            use_case="Data at rest encryption, NIST approved",
            security_strength="NIST approved, no known practical attacks",
            pros=[
                "Very fast software implementation",
                "Efficient hardware implementation",
                "Widely supported",
                "NIST standard",
                "256-bit variant resistant to quantum attacks",
            ],
            cons=["Requires secure key management", "No built-in authentication"],
        ),
        CryptographicAlgorithm(
            name="ChaCha20",
            category="Symmetric",
            key_size="256 bits",
            use_case="Stream encryption, DTLS, TLS",
            security_strength="Not broken, modern design",
            pros=[
                "Faster on non-AES hardware",
                "No patent restrictions",
                "Simple and elegant design",
                "Good performance on mobile",
            ],
            cons=["Less tested than AES", "Smaller security margin"],
        ),
    ]
    
    ASYMMETRIC_ALGORITHMS = [
        CryptographicAlgorithm(
            name="RSA",
            category="Asymmetric",
            key_size="2048 bits minimum (4096 recommended)",
            use_case="Key exchange, digital signatures",
            security_strength="Secure if key size ≥ 2048 bits",
            pros=[
                "Well understood mathematically",
                "Widely implemented",
                "Good for digital signatures",
            ],
            cons=[
                "Slower than symmetric",
                "Key size growing due to attacks",
                "Vulnerable to quantum computers",
                "Padding required",
            ],
        ),
        CryptographicAlgorithm(
            name="Elliptic Curve Cryptography (ECC)",
            category="Asymmetric",
            key_size="256 bits equivalent to 3072-bit RSA",
            use_case="Modern key exchange, signatures, TLS",
            security_strength="256-bit ECC = 128-bit symmetric security",
            pros=[
                "Smaller key sizes",
                "Faster computation",
                "Better security per bit",
                "Modern standard",
            ],
            cons=[
                "More complex mathematics",
                "Implementation pitfalls",
                "Patent concerns (mostly resolved)",
            ],
        ),
    ]
    
    HASHING_ALGORITHMS = [
        CryptographicAlgorithm(
            name="SHA-256",
            category="Hashing",
            key_size="256-bit output",
            use_case="Data integrity, password hashing (with salt)",
            security_strength="Cryptographically secure, NIST approved",
            pros=[
                "Well analyzed",
                "No known attacks",
                "Fast",
                "NIST standard",
            ],
            cons=["Vulnerable to rainbow tables without salt"],
        ),
        CryptographicAlgorithm(
            name="SHA-3 (Keccak)",
            category="Hashing",
            key_size="256-bit output",
            use_case="Data integrity, future-proofing",
            security_strength="Different design from SHA-2, modern",
            pros=[
                "Different design from SHA-2",
                "Can squeeze arbitrary length output",
                "Future-proof choice",
            ],
            cons=["Less widely deployed than SHA-256"],
        ),
        CryptographicAlgorithm(
            name="bcrypt",
            category="Key Derivation",
            key_size="Variable",
            use_case="Password hashing",
            security_strength="Deliberately slow to resist brute force",
            pros=[
                "Slow (good for passwords)",
                "Salted by default",
                "Adjustable work factor",
                "Simple API",
            ],
            cons=["Slower than optimal for non-password use"],
        ),
    ]
    
    KEY_EXCHANGE_PROTOCOLS = [
        {
            "protocol": "ECDHE (Elliptic Curve Diffie-Hellman Ephemeral)",
            "category": "Key Exchange",
            "properties": {
                "forward_secrecy": True,
                "post_quantum_resistant": False,
                "performance": "Fast",
            },
            "use_in": "TLS 1.3, modern protocols",
            "recommendation": "Use with TLS 1.3",
        },
        {
            "protocol": "DH (Diffie-Hellman)",
            "category": "Key Exchange",
            "properties": {
                "forward_secrecy": False,
                "post_quantum_resistant": False,
                "performance": "Slower",
            },
            "use_in": "Legacy protocols",
            "recommendation": "Deprecated, use ECDHE",
        },
    ]
    
    AUTHENTICATION_METHODS = [
        {
            "method": "HMAC-SHA256",
            "purpose": "Message authentication codes",
            "properties": ["Fast", "Deterministic", "Requires shared key"],
            "use_case": "API authentication, integrity checking",
        },
        {
            "method": "Digital Signatures (RSA, ECDSA)",
            "purpose": "Non-repudiation and authentication",
            "properties": ["Public key verification", "Cannot deny later"],
            "use_case": "Document signing, certificate authority",
        },
        {
            "method": "Certificates (X.509)",
            "purpose": "Public key infrastructure",
            "properties": ["Trusted third party", "Chain of trust"],
            "use_case": "TLS/SSL, code signing",
        },
    ]
    
    MATHEMATICAL_FOUNDATIONS = [
        {
            "concept": "Prime Numbers",
            "importance": "Foundation of RSA",
            "algorithm": "Generate large cryptographic primes",
            "property": "Used to create one-way functions",
        },
        {
            "concept": "Elliptic Curves",
            "importance": "Foundation of ECC",
            "algorithm": "Points on curve y²=x³+ax+b (mod p)",
            "property": "Discrete log problem is hard",
        },
        {
            "concept": "Discrete Logarithm Problem",
            "importance": "Security of DH and ECC",
            "algorithm": "Given g, a, find n where a = g^n mod p",
            "property": "Computationally infeasible with large numbers",
        },
        {
            "concept": "Random Number Generation",
            "importance": "Critical for all cryptography",
            "algorithm": "Cryptographically secure RNG",
            "property": "Must be truly random, not pseudo-random",
        },
    ]
    
    SECURE_PROTOCOL_RECOMMENDATIONS = [
        {
            "protocol": "TLS 1.3",
            "recommendation": "MUST use for HTTPS",
            "configuration": {
                "cipher_suites": ["TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256"],
                "key_exchange": "ECDHE",
                "minimum_key_size": "256 bits",
            },
            "disabled": ["TLS 1.0", "TLS 1.1", "TLS 1.2 without AEAD"],
        },
        {
            "protocol": "SSH",
            "recommendation": "Use SSH-2 only",
            "configuration": {
                "key_exchange": "ECDH, Diffie-Hellman-Group16",
                "authentication": "ED25519 keys preferred",
                "encryption": "AES-256-GCM, ChaCha20",
            },
        },
    ]
    
    def get_algorithm_by_use_case(self, use_case: str) -> dict:
        """Get recommended algorithms for use case.
        
        Args:
            use_case: Type of encryption needed
            
        Returns:
            Recommended algorithms
        """
        recommendations = {
            "data_at_rest": {
                "algorithm": "AES-256-GCM",
                "key_derivation": "PBKDF2 or Argon2",
                "reason": "Fast, NIST approved, authenticated encryption",
            },
            "data_in_transit": {
                "algorithm": "TLS 1.3 with ECDHE-ECDSA",
                "cipher": "AES-256-GCM or ChaCha20-Poly1305",
                "reason": "Forward secrecy, authenticated, modern",
            },
            "password_storage": {
                "algorithm": "bcrypt or Argon2",
                "parameters": "Work factor ≥ 12",
                "reason": "Slow, salted, resistant to brute force",
            },
            "digital_signatures": {
                "algorithm": "ECDSA with SHA-256 or EdDSA",
                "key_size": "256 bits minimum",
                "reason": "Fast verification, good security",
            },
        }
        
        return recommendations.get(use_case.lower(), {
            "error": f"Unknown use case: {use_case}",
            "available": list(recommendations.keys()),
        })
    
    def get_quantum_resistant_options(self) -> dict:
        """Get post-quantum cryptography recommendations.
        
        Returns:
            Quantum-resistant algorithms and approaches
        """
        return {
            "current_status": "Quantum computers not yet practical for cryptanalysis",
            "recommendations": [
                "Use 256-bit symmetric keys (resistant to Grover's algorithm)",
                "Avoid RSA and ECC (vulnerable to Shor's algorithm)",
                "Research NIST PQC candidates: CRYSTALS-Kyber, CRYSTALS-Dilithium",
                "Plan migration timeline for post-quantum crypto",
            ],
            "timeline": "Expected standardization by 2024-2025",
        }


class CryptographyExpert:
    """Expert module for cryptography and mathematical algorithms."""
    
    def __init__(self):
        """Initialize cryptography expert."""
        self.kb = CryptographyKnowledgeBase()
        self.name = "Cryptography Expert"
        self.specialties = [
            "Encryption Algorithms",
            "Key Management",
            "Secure Protocols",
            "Digital Signatures",
            "Mathematical Foundations",
            "Post-Quantum Cryptography",
        ]
    
    def recommend_encryption(self, use_case: str) -> dict:
        """Recommend encryption method for use case.
        
        Args:
            use_case: Type of encryption needed
            
        Returns:
            Algorithm recommendation with rationale
        """
        return self.kb.get_algorithm_by_use_case(use_case)
    
    def analyze_algorithm(self, algorithm_name: str) -> dict:
        """Analyze specific cryptographic algorithm.
        
        Args:
            algorithm_name: Name of algorithm
            
        Returns:
            Detailed algorithm analysis
        """
        # Search in all algorithm lists
        all_algorithms = (
            self.kb.SYMMETRIC_ALGORITHMS +
            self.kb.ASYMMETRIC_ALGORITHMS +
            self.kb.HASHING_ALGORITHMS
        )
        
        for algo in all_algorithms:
            if algo.name.lower() == algorithm_name.lower():
                return {
                    "name": algo.name,
                    "category": algo.category,
                    "key_size": algo.key_size,
                    "use_case": algo.use_case,
                    "security_strength": algo.security_strength,
                    "advantages": algo.pros,
                    "disadvantages": algo.cons,
                }
        
        return {
            "error": f"Algorithm not found: {algorithm_name}",
            "available_symmetric": [a.name for a in self.kb.SYMMETRIC_ALGORITHMS],
            "available_asymmetric": [a.name for a in self.kb.ASYMMETRIC_ALGORITHMS],
        }
    
    def get_protocol_security_config(self, protocol: str) -> dict:
        """Get secure configuration for protocol.
        
        Args:
            protocol: Protocol name (TLS, SSH, etc.)
            
        Returns:
            Secure configuration recommendations
        """
        for rec in self.kb.SECURE_PROTOCOL_RECOMMENDATIONS:
            if rec["protocol"].lower() == protocol.lower():
                return rec
        
        return {"error": f"Protocol not found: {protocol}"}
    
    def get_quantum_readiness(self) -> dict:
        """Get quantum computing readiness assessment.
        
        Returns:
            Post-quantum cryptography recommendations
        """
        return self.kb.get_quantum_resistant_options()
    
    def get_key_sizes(self) -> dict:
        """Get recommended key sizes for different security levels.
        
        Returns:
            Key size recommendations
        """
        return {
            "security_levels": {
                "128-bit": {
                    "equivalent_symmetric": "128-bit",
                    "equivalent_rsa": "3072-bit",
                    "equivalent_ecc": "256-bit",
                    "use_for": "Short-term security (< 50 years)",
                },
                "192-bit": {
                    "equivalent_symmetric": "192-bit",
                    "equivalent_rsa": "7680-bit",
                    "equivalent_ecc": "384-bit",
                    "use_for": "Very sensitive data",
                },
                "256-bit": {
                    "equivalent_symmetric": "256-bit",
                    "equivalent_rsa": "15360-bit",
                    "equivalent_ecc": "521-bit",
                    "use_for": "Top secret, future-proof",
                },
            }
        }
    
    def get_summary(self) -> dict:
        """Get expert summary."""
        return {
            "expert": self.name,
            "specialties": self.specialties,
            "knowledge_areas": {
                "symmetric_algorithms": len(self.kb.SYMMETRIC_ALGORITHMS),
                "asymmetric_algorithms": len(self.kb.ASYMMETRIC_ALGORITHMS),
                "hashing_algorithms": len(self.kb.HASHING_ALGORITHMS),
                "key_exchange_protocols": len(self.kb.KEY_EXCHANGE_PROTOCOLS),
                "authentication_methods": len(self.kb.AUTHENTICATION_METHODS),
                "mathematical_foundations": len(self.kb.MATHEMATICAL_FOUNDATIONS),
            },
            "total_knowledge_items": 40,
        }
