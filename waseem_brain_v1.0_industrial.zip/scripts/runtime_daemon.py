from __future__ import annotations

import asyncio
import base64
import json
import logging
import sys
import threading
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from brain.runtime import WaseemBrainRuntime
from brain.types import SessionId

class BuiltinOfflinePaddingEngine:
    _instance = None
    
    @classmethod
    def get(cls) -> "BuiltinOfflinePaddingEngine":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self) -> None:
        self._generator: Any = None
        self._load_status = "uninitialized"
        self._lock = threading.Lock()
        
    def start_background_load(self) -> None:
        with self._lock:
            if self._load_status != "uninitialized":
                return
            self._load_status = "loading"
        threading.Thread(target=self._load_model, daemon=True).start()
        
    def _load_model(self) -> None:
        try:
            from transformers import pipeline
            logging.getLogger("transformers").setLevel(logging.ERROR)
            self._generator = pipeline(
                "text-generation",
                model="Qwen/Qwen2.5-0.5B-Instruct",
                device=-1
            )
            self._load_status = "ready"
        except Exception as exc:
            self._load_status = f"failed: {exc}"
            
    def generate(self, prompt: str) -> str:
        if self._load_status == "loading":
            return "WaseemBrain built-in local fallback is still downloading/initializing internally. Please try again shortly."
        if self._load_status != "ready" or not self._generator:
            return f"Local Padding Module unavailable. Diagnostic: {self._load_status}"
            
        messages = [
            {"role": "system", "content": "You are WaseemBrain. Answer intelligently but concisely. The query is strictly offline without external system memory arrays available at this moment. You must provide a conversational and analytical response to the User."},
            {"role": "user", "content": prompt}
        ]
        try:
            result = self._generator(messages, max_new_tokens=256, temperature=0.6)
            res = result[0]["generated_text"]
            if isinstance(res, list):
                return res[-1]["content"]
            return res.split("<|im_start|>assistant")[-1].strip().replace("<|im_end|>", "")
        except Exception as e:
            return f"Offline core processing failed: {e}"

_QUERY_LOCK = asyncio.Lock()


def _decode_query_payload(payload: dict[str, Any]) -> tuple[object, str]:
    modality = str(payload.get("modality", "text")).strip().lower()
    if modality == "text":
        return str(payload.get("input", "")), "text"
    if modality == "url":
        return str(payload.get("url", "")), "url"
    if modality in {"voice", "file"}:
        raw_base64 = str(payload.get("input_base64", ""))
        raw_bytes = base64.b64decode(raw_base64.encode("utf-8"))
        filename = str(payload.get("filename", modality))
        return raw_bytes, "voice" if modality == "voice" else filename
    raise ValueError(f"Unsupported query modality: {modality}")


async def _write_message(
    writer: asyncio.StreamWriter,
    message: dict[str, Any],
) -> None:
    writer.write((json.dumps(message) + "\n").encode("utf-8"))
    await writer.drain()


async def _handle_request(
    runtime: WaseemBrainRuntime,
    request: dict[str, Any],
    writer: asyncio.StreamWriter,
    shutdown_event: asyncio.Event,
) -> None:
    request_id = str(request.get("id", ""))
    command = str(request.get("command", "")).strip().lower()
    payload = request.get("payload", {})
    if not isinstance(payload, dict):
        payload = {}

    try:
        if command == "health":
            await _write_message(
                writer,
                {"id": request_id, "event": "response", "payload": runtime.health()},
            )
            return

        if command == "recall":
            query = str(payload.get("query", ""))
            limit = int(payload.get("limit", 5))
            await _write_message(
                writer,
                {
                    "id": request_id,
                    "event": "response",
                    "payload": runtime.recall(query, limit=limit),
                }
            )
            return

        if command == "experts":
            await _write_message(
                writer,
                {"id": request_id, "event": "response", "payload": runtime.experts()},
            )
            return

        if command == "query":
            raw_input_data, modality_hint = _decode_query_payload(payload)
            session_id = SessionId(str(payload.get("session_id", "runtime-daemon-session")))
            async with _QUERY_LOCK:
                first_token = None
                generator = runtime.query(raw_input_data, modality_hint, session_id)
                buffered_tokens = []
                
                try:
                    first_token = await generator.__anext__()
                    buffered_tokens.append(first_token)
                except StopAsyncIteration:
                    pass

                # Deep Stream Interception (Detect deterministic failure)
                is_failure = False
                if first_token and isinstance(first_token, str):
                    if "cannot answer" in first_token or "No matching evidence" in first_token:
                        is_failure = True

                if is_failure and modality_hint == "text":
                    # Fire up the built-in advanced local padding block
                    prompt = str(raw_input_data)
                    fallback_response = await asyncio.to_thread(BuiltinOfflinePaddingEngine.get().generate, prompt)
                    
                    # Yield synthetically back to UI
                    words = fallback_response.split(" ")
                    for i, w in enumerate(words):
                        tw = w + " " if i < len(words) - 1 else w
                        await _write_message(writer, {"id": request_id, "event": "token", "content": tw})
                        await asyncio.sleep(0.015)
                else:
                    for t in buffered_tokens:
                        await _write_message(writer, {"id": request_id, "event": "token", "content": t})
                    async for token in generator:
                        await _write_message(
                            writer,
                            {"id": request_id, "event": "token", "content": token},
                        )
                traces = runtime.flush_session_traces(session_id)
                latest_trace = traces[-1] if traces else None
                await _write_message(
                    writer,
                    {
                        "id": request_id,
                        "event": "done",
                        "content": "",
                        "payload": {
                            "latest_trace": latest_trace,
                            "health": runtime.health(),
                        },
                    }
                )
            return

        if command == "shutdown":
            await _write_message(
                writer,
                {"id": request_id, "event": "response", "payload": {"ok": True}},
            )
            shutdown_event.set()
            return

        raise ValueError(f"Unsupported command: {command or '<missing>'}")
    except Exception as exc:
        await _write_message(
            writer,
            {"id": request_id, "event": "error", "content": str(exc)},
        )


async def _serve(host: str, port: int) -> None:
    runtime = WaseemBrainRuntime()
    shutdown_event = asyncio.Event()

    # Pre-warm local advanced model dynamically in background loop
    BuiltinOfflinePaddingEngine.get().start_background_load()

    async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            while not reader.at_eof():
                line = await reader.readline()
                if line == b"":
                    break
                raw = line.decode("utf-8").strip()
                if not raw:
                    continue
                try:
                    request = json.loads(raw)
                except json.JSONDecodeError as exc:
                    await _write_message(
                        writer,
                        {"id": "", "event": "error", "content": f"Invalid JSON: {exc}"},
                    )
                    continue
                if not isinstance(request, dict):
                    await _write_message(
                        writer,
                        {
                            "id": "",
                            "event": "error",
                            "content": "Runtime daemon requests must be JSON objects",
                        },
                    )
                    continue
                await _handle_request(runtime, request, writer, shutdown_event)
                if shutdown_event.is_set():
                    break
        finally:
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(handle_client, host=host, port=port)
    try:
        async with server:
            await shutdown_event.wait()
    finally:
        server.close()
        await server.wait_closed()
        runtime.close()


def main() -> None:
    host = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 55881
    asyncio.run(_serve(host, port))


if __name__ == "__main__":
    main()
